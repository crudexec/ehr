import { ConnectionOptions } from 'typeorm';
import { SnakeNamingStrategy } from 'typeorm-naming-strategies';

const isProd = process.env.NODE_ENV !== 'dev';
const basePath = isProd ? 'dist' : 'src';

const config: ConnectionOptions = {
  type: 'postgres',
  name: 'default',
  url: process.env.DB_URL,
  synchronize: false,
  logging: false,
  entities: [`src/orm/entities/**/*.{js,ts}`],
  migrations: [`src/orm/migrations/**/*.{js,ts}`],
  subscribers: [`src/orm/subscriber/**/*.{js,ts}`],
  cli: {
    entitiesDir: 'src/orm/entities',
    migrationsDir: 'src/orm/migrations',
    subscribersDir: 'src/orm/subscriber',
  },
  namingStrategy: new SnakeNamingStrategy(),
};

export default config;
