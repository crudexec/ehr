export enum Role {
  ADMINISTRATOR = 'ADMINISTRATOR',
  STANDARD = 'STANDARD',
}

export type Language = 'en-US' | 'sl-SI';
