export const positionOverview = {
  'DSP (Direct Care Worker)': `The Direct Care Worker plays a vital role in providing essential support and assistance to individuals in need of direct care services. This position requires compassionate individuals who
    are dedicated to improving the quality of life for vulnerable populations. As a Direct Care Worker in the state of Maryland, you will be responsible for providing care, support, and supervision to
    individuals in various settings, ensuring their safety, well-being, and overall comfort.`,
  'On-Call Professional': `The On-Call Professional in the Autism Waiver program is responsible for providing emergency support and guidance to individuals with autism and their families or caregivers during non-standard hours. This role aims to ensure the safety, well-being, and appropriate care of individuals with autism, especially during challenging situations or crises.
    `,
  'Family Consultant': `A Family Consultant in Maryland provides professional training, guidance and consultation
    support and resources to individuals and families facing various personal, emotional, and
    interpersonal challenges. They work collaboratively with clients to assess their needs, develop
    tailored intervention plans, and resources to enhance their overall quality of life.`,
  'Intensive Individual Support Services(IISS)': `The IISS Director in Maryland is responsible for the overall leadership, administration, and coordination of intensive support services designed to improve the quality of life and independence of individuals with significant developmental, behavioral, or mental health challenges. This role involves program development, staff supervision, budget management, and compliance with Maryland state regulations.`,
};
