import { Request, Response, NextFunction } from 'express';
import { getRepository } from 'typeorm';
import { SpecificNeedsFullForm } from '../../orm/entities/SpecificNeedsForm/SpecificNeedsFullForm';
import { SpecificNeedsBasicInformation } from 'orm/entities/SpecificNeedsForm/BasicInformation';
import { JwtPayload } from 'types/JwtPayload';
import { CustomError } from 'utils/response/custom-error/CustomError';
import { Status } from 'types/genericEnums';

interface RequestWithJwtPayload extends Request {
  req: RequestWithJwtPayload;
  user: JwtPayload;
}

export const addBasicInformation = async (req: RequestWithJwtPayload, res: Response, next: NextFunction) => {
  try {
    const specificNeedsRepository = getRepository(SpecificNeedsFullForm);
    const basicInformationRepository = getRepository(SpecificNeedsBasicInformation);
    const registered_by = req.user.id;

    const {
      participant_first_name,
      participant_last_name,
      participant_father_name,
      participant_mother_name,
      gender,
      date_of_birth,
      father_mobile_number,
      mother_mobile_number,
      home_address,
      specific_needs_implemented_by,
      specific_needs_full_form_id,
      intake_full_id,
    } = req.body;

    const specificNeedsForm = await specificNeedsRepository.findOne({
      where: {
        id: specific_needs_full_form_id,
        deleted_at: null,
      },
    });

    if (!specificNeedsForm) {
      const customError = new CustomError(404, 'General', 'Specific needs form not found', null);
      return next(customError);
    }

    const basicInformation = new SpecificNeedsBasicInformation();
    basicInformation.participant_first_name = participant_first_name;
    basicInformation.participant_last_name = participant_last_name;
    basicInformation.participant_father_name = participant_father_name;
    basicInformation.participant_mother_name = participant_mother_name;
    basicInformation.gender = gender;
    basicInformation.date_of_birth = new Date(date_of_birth);
    basicInformation.father_mobile_number = father_mobile_number;
    basicInformation.mother_mobile_number = mother_mobile_number;
    basicInformation.home_address = home_address;
    basicInformation.specific_needs_implemented_by = specific_needs_implemented_by;
    basicInformation.intake_full_id = intake_full_id;
    basicInformation.registered_by = registered_by;

    const newBasicInformation = await basicInformationRepository.save(basicInformation);

    if (!newBasicInformation) {
      const customError = new CustomError(400, 'Raw', 'Error adding basic information', null);
      return next(customError);
    }

    specificNeedsForm.basic_information_id = newBasicInformation.id;
    specificNeedsForm.status = Status.IN_PROGRESS;

    await specificNeedsRepository.update(specificNeedsForm.id, specificNeedsForm);

    return res.customSuccess(200, 'Basic information added successfully.', newBasicInformation);
  } catch (error) {
    const customError = new CustomError(400, 'Raw', 'Error adding basic information', error);
    return next(customError);
  }
};
