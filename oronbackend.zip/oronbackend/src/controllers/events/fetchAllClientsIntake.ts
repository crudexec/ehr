import { Request, Response, NextFunction } from 'express';
import { getRepository } from 'typeorm';

import { IntakeFullForm } from 'orm/entities/IntakeForm/intakeFullForm';
import { TreatmentFullPlan } from 'orm/entities/TreatmentPlan/treatmentFullPlan';
import { JwtPayload } from 'types/JwtPayload';
import { CustomError } from 'utils/response/custom-error/CustomError';

interface RequestWithJwtPayload extends Request {
  req: RequestWithJwtPayload;
  user: JwtPayload;
}

export const fetchAllClientsIntake = async (req: RequestWithJwtPayload, res: Response, next: NextFunction) => {
  try {
    const account_id = req.user.account_id;

    const intakeFullFormRepository = getRepository(IntakeFullForm);
    const treatmentFullPlanRepository = getRepository(TreatmentFullPlan);

    const intakeDataArray = [];

    const intakes = await intakeFullFormRepository.find({ where: { account_id, deleted_at: null } });
    let temp = {};
    for (const intake of intakes) {
      const treatmentPlan = await treatmentFullPlanRepository.findOne({
        where: { intake_full_id: intake.id, deleted_at: null },
      });
      if (treatmentPlan) {
        temp = { ...intake, treatment_plan_exists: true };
      } else {
        temp = { ...intake, treatment_plan_exists: false };
      }
      intakeDataArray.push(temp);
    }

    return res.customSuccess(200, 'Clients Intake Retrieved Successfully', intakeDataArray);
  } catch (err) {
    const customError = new CustomError(400, 'Raw', 'Error Retrieving Intakes', null, err);
    return next(customError);
  }
};
