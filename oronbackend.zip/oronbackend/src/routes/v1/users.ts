import { Router } from 'express';

import { fetchUserForms } from 'controllers/admin';
import { fetchUsers, fetchUserApprovedForms, fetchUserAwaitingForms, fetchUserNotFilledForms } from 'controllers/admin';
import {
  list,
  show,
  edit,
  destroy,
  uploadUserDocument,
  retrieveUserDocuments,
  editUserDocument,
  SignOfferLetter,
  RetrieveOfferLetter,
} from 'controllers/users';
import { checkJwt } from 'middleware/checkJwt';
import { checkRole } from 'middleware/checkRole';
import { validatorEdit } from 'middleware/validation/users';

const router = Router();

router.get('/', [checkJwt], show);
router.get('/all', [checkJwt], list);
router.patch('/', [checkJwt], edit);
router.delete('/', [checkJwt], destroy);
router.get('/all/users', [checkJwt, checkRole('ADMINISTRATOR')], fetchUsers);
router.get('/:id/forms', [checkJwt, checkRole('ADMINISTRATOR')], fetchUserForms);
router.get('/:id/forms/awaiting-approval', [checkJwt, checkRole('ADMINISTRATOR')], fetchUserAwaitingForms);
router.get('/:id/forms/approved', [checkJwt, checkRole('ADMINISTRATOR')], fetchUserApprovedForms);
router.get('/:id/forms/not-filled', [checkJwt, checkRole('ADMINISTRATOR')], fetchUserNotFilledForms);
router.post('/upload/document', [checkJwt], uploadUserDocument);
router.get('/retrieve/documents', [checkJwt], retrieveUserDocuments);
router.patch('/:document_id/edit/document', [checkJwt], editUserDocument);
router.patch('/sign/offer-letter', [checkJwt], SignOfferLetter);
router.get('/retrieve/offer-letter', [checkJwt], RetrieveOfferLetter);

export default router;
