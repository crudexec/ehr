import { Router } from 'express';

import {
  ApproveBioDataForm,
  ApproveI9Form,
  ApproveDemographicForm,
  ApproveFluForm,
  ApproveHepatitisForm,
  ApproveInfluenzaForm,
  ApproveMMRForm,
  ApproveTbForm,
  ApproveVaricellaForm,
  ApprovePneumococcalForm,
  ApproveN95Form,
  ReviewBioDataForm,
  ReviewI9Form,
  ReviewDemographicForm,
  ReviewFluForm,
  ReviewHepatitisForm,
  ReviewInfluenzaForm,
  ReviewMMRForm,
  ReviewTbForm,
  ReviewVaricellaForm,
  ReviewPneumococcalForm,
  ApproveCJISForm,
  ReviewReferenceForm,
  ReviewCJISForm,
  ApproveReferenceForm,
  SendOfferLetter,
  SearchUser,
  RetrieveUserOfferLetter,
  fetchUserDocuments,
  ApproveUserDocument,
  ReviewUserDocument,
} from 'controllers/admin';
import { checkJwt } from 'middleware/checkJwt';
import { checkRole } from 'middleware/checkRole';

const router = Router();

router.patch('/:id/i9form', [checkJwt, checkRole('ADMINISTRATOR')], ApproveI9Form);
router.patch('/:id/biodata', [checkJwt, checkRole('ADMINISTRATOR')], ApproveBioDataForm);
router.patch('/:id/demographic', [checkJwt, checkRole('ADMINISTRATOR')], ApproveDemographicForm);
router.patch('/:id/flu', [checkJwt, checkRole('ADMINISTRATOR')], ApproveFluForm);
router.patch('/:id/hepatitis', [checkJwt, checkRole('ADMINISTRATOR')], ApproveHepatitisForm);
router.patch('/:id/influenza', [checkJwt, checkRole('ADMINISTRATOR')], ApproveInfluenzaForm);
router.patch('/:id/mmr', [checkJwt, checkRole('ADMINISTRATOR')], ApproveMMRForm);
router.patch('/:id/tb', [checkJwt, checkRole('ADMINISTRATOR')], ApproveTbForm);
router.patch('/:id/varicella', [checkJwt, checkRole('ADMINISTRATOR')], ApproveVaricellaForm);
router.patch('/:id/pneumococcal', [checkJwt, checkRole('ADMINISTRATOR')], ApprovePneumococcalForm);
router.patch('/:id/n95', [checkJwt, checkRole('ADMINISTRATOR')], ApproveN95Form);
router.patch('/:id/review/biodata', [checkJwt, checkRole('ADMINISTRATOR')], ReviewBioDataForm);
router.patch('/:id/review/i9form', [checkJwt], ReviewI9Form);
router.patch('/:id/review/demographic', [checkJwt, checkRole('ADMINISTRATOR')], ReviewDemographicForm);
router.patch('/:id/review/flu', [checkJwt, checkRole('ADMINISTRATOR')], ReviewFluForm);
router.patch('/:id/review/hepatitis', [checkJwt, checkRole('ADMINISTRATOR')], ReviewHepatitisForm);
router.patch('/:id/review/influenza', [checkJwt, checkRole('ADMINISTRATOR')], ReviewInfluenzaForm);
router.patch('/:id/review/mmr', [checkJwt, checkRole('ADMINISTRATOR')], ReviewMMRForm);
router.patch('/:id/review/tb', [checkJwt, checkRole('ADMINISTRATOR')], ReviewTbForm);
router.patch('/:id/review/varicella', [checkJwt, checkRole('ADMINISTRATOR')], ReviewVaricellaForm);
router.patch('/:id/review/pneumococcal', [checkJwt, checkRole('ADMINISTRATOR')], ReviewPneumococcalForm);
router.patch('/:id/review/reference', [checkJwt, checkRole('ADMINISTRATOR')], ReviewReferenceForm);
router.patch('/:id/review/cjis', [checkJwt, checkRole('ADMINISTRATOR')], ReviewCJISForm);
router.patch('/:id/cjis', [checkJwt, checkRole('ADMINISTRATOR')], ApproveCJISForm);
router.patch('/:id/reference', [checkJwt, checkRole('ADMINISTRATOR')], ApproveReferenceForm);
router.post('/:user_id/send-offer-letter', [checkJwt, checkRole('ADMINISTRATOR')], SendOfferLetter);
router.get('/search', [checkJwt, checkRole('ADMINISTRATOR')], SearchUser);
router.get('/:user_id/retrieve/offer-letter', [checkJwt, checkRole('ADMINISTRATOR')], RetrieveUserOfferLetter);
router.get('/:user_id/retrieve/user/documents', [checkJwt, checkRole('ADMINISTRATOR')], fetchUserDocuments);
router.patch('/:id/user/document', [checkJwt, checkRole('ADMINISTRATOR')], ApproveUserDocument);
router.patch('/:id/user/review/document', [checkJwt, checkRole('ADMINISTRATOR')], ReviewUserDocument);

export default router;
